package com.example.piotr.projektinz;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;



public class dni_tygodnia extends AppCompatActivity  {

    static WebView webview;
    static ProgressBar progressbar;

   static class plan_dnia_poniedzialek extends AppCompatActivity {
       @Override
       protected void onCreate(Bundle savedInstanceState) {
           super.onCreate(savedInstanceState);
           setContentView(R.layout.plan_dnia);
           webview = findViewById(R.id.webview);
           progressbar = findViewById(R.id.progressbar);
           webview.getSettings().setJavaScriptEnabled(true);
           String filename = "https://el.pcz.pl/images/timetables/1_PONIEDZIALEK.pdf";
           String url = "https://docs.google.com/gview?embedded=true&url=" + filename;
           webview.setWebViewClient(new WebViewClient() {

               public void onPageFinished(WebView view, String url) {
                   progressbar.setVisibility(View.GONE);
               }
           });
           webview.loadUrl(url);
       }
   }
    static class plan_dnia_wtorek extends AppCompatActivity {
       @Override
       protected void onCreate(Bundle savedInstanceState) {
           super.onCreate(savedInstanceState);
           setContentView(R.layout.plan_dnia);
           webview = findViewById(R.id.webview);
           progressbar = findViewById(R.id.progressbar);
           webview.getSettings().setJavaScriptEnabled(true);
           String filename ="https://el.pcz.pl/images/timetables/2_WTOREK.pdf";
           webview.loadUrl("https://docs.google.com/gview?embedded=true&url=" + filename);
           webview.setWebViewClient(new WebViewClient() {

               public void onPageFinished(WebView view, String url) {
                   progressbar.setVisibility(View.GONE);
               }
           });
       }
   }
    static class plan_dnia_sroda extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.plan_dnia);
            webview = findViewById(R.id.webview);
            progressbar = findViewById(R.id.progressbar);
            webview.getSettings().setJavaScriptEnabled(true);
            String filename ="https://el.pcz.pl/images/timetables/3_SRODA.pdf";
            webview.loadUrl("https://docs.google.com/gview?embedded=true&url=" + filename);

            webview.setWebViewClient(new WebViewClient() {

                public void onPageFinished(WebView view, String url) {
                    progressbar.setVisibility(View.GONE);
                }
            });

        }
    }
    static class plan_dnia_czwartek extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.plan_dnia);
            webview = findViewById(R.id.webview);
            progressbar = findViewById(R.id.progressbar);
            webview.getSettings().setJavaScriptEnabled(true);
            String filename ="https://el.pcz.pl/images/timetables/4_CZWARTEK.pdf";
            webview.loadUrl("https://docs.google.com/gview?embedded=true&url=" + filename);

            webview.setWebViewClient(new WebViewClient() {

                public void onPageFinished(WebView view, String url) {
                    progressbar.setVisibility(View.GONE);
                }
            });

        }
    }
    static class plan_dnia_piatek extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.plan_dnia);
            webview = findViewById(R.id.webview);
            progressbar = findViewById(R.id.progressbar);
            webview.getSettings().setJavaScriptEnabled(true);
            String filename ="https://el.pcz.pl/images/timetables/5_PIATEK.pdf";
            webview.loadUrl("https://docs.google.com/gview?embedded=true&url=" + filename);

            webview.setWebViewClient(new WebViewClient() {

                public void onPageFinished(WebView view, String url) {
                    progressbar.setVisibility(View.GONE);
                }
            });

        }
    }
}




